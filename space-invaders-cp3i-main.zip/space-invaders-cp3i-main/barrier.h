#ifndef BARRIER_H

#define BARRIER_H

class barrier{
public:    
        barrier(float, float);
        float getX(void );
        float getY(void ); 
private:
        float x,y;   
};

#endif
